
function affineCipher(text, a, b, encode = true) {
    const Z29 = 'abcdefghijklmnopqrstuvwxyz@.-';
    const result = [];
    const m = 29;  
    function modInverse(a, m) {
        for (let i = 1; i < m; i++) {
            if ((a * i) % m === 1) {
                return i;
            }
        }
        return -1; 
    }
    const aInverse = modInverse(a, m);
    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        const index = Z29.indexOf(char); 
        if (index !== -1) {
            if (encode) {
                const encodedIndex = (a * index + b) % m;
                result.push(Z29[encodedIndex]);
            } else {
                const decodedIndex = (aInverse * (index - b + m)) % m;
                result.push(Z29[decodedIndex]);
            }
        } else {
            result.push(char);
        }
    }
    return result.join('');
}
document.getElementById('cipherForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const action = document.getElementById('action').value;
    const output = document.getElementById('output');
    const resultDiv = document.getElementById('result');
    const a = 7;  
    const b = 13; 
    const isEncode = (action === 'encode');
    const result = affineCipher(email, a, b, isEncode);
    output.textContent = result;
    resultDiv.style.display = 'block';
});
